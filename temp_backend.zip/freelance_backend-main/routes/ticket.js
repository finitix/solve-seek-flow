const express = require('express');
const authMiddleware = require('../middleware/auth');
const Ticket = require('../models/Ticket');
const Teacher = require('../models/Teacher');
const Category = require('../models/Category');
const nodemailer = require('nodemailer');

const router = express.Router();

// Configure Nodemailer
const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false,
  requireTLS: true,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
  tls: {
    rejectUnauthorized: false
  }
});

// ==================== CREATE TICKET (Student Only) ====================
// Student creates a ticket/issue in a category
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { title, description, category, budget, deadline } = req.body;

    // Validate required fields
    if (!title || !description || !category) {
      return res.status(400).json({ error: 'Title, description, and category are required' });
    }

    // Verify category exists
    const categoryExists = await Category.findById(category);
    if (!categoryExists) {
      return res.status(404).json({ error: 'Category not found' });
    }

    // Create new ticket
    const ticket = new Ticket({
      title: title.trim(),
      description: description.trim(),
      category,
      student: req.user._id,
      budget: budget || null,
      deadline: deadline || null,
      requestedTeachers: [],
    });

    await ticket.save();

    // Populate references
    await ticket.populate('category', 'name');
    await ticket.populate('student', 'name email');

    res.status(201).json({
      message: 'Ticket created successfully',
      ticket,
    });
  } catch (error) {
    console.error('Error creating ticket:', error);
    res.status(500).json({ error: error.message || 'Failed to create ticket' });
  }
});

// ==================== GET RECOMMENDED TEACHERS ====================
// Get top 5 teachers in the ticket's category
router.get('/:ticketId/recommended-teachers', authMiddleware, async (req, res) => {
  try {
    const { ticketId } = req.params;

    // Find ticket
    const ticket = await Ticket.findById(ticketId);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    // Get top 5 teachers in the category (sorted by rating)
    const teachers = await Teacher.find({ category: ticket.category })
      .populate('category', 'name')
      .sort({ rating: -1 })
      .limit(5);

    res.json({
      message: 'Recommended teachers fetched successfully',
      totalTeachers: teachers.length,
      teachers,
    });
  } catch (error) {
    console.error('Error fetching recommended teachers:', error);
    res.status(500).json({ error: 'Failed to fetch recommended teachers' });
  }
});

// ==================== SEND REQUEST TO TEACHER ====================
// Student sends request to teacher for a ticket
router.post('/:ticketId/request-teacher', authMiddleware, async (req, res) => {
  try {
    const { ticketId } = req.params;
    const { teacherId } = req.body;

    if (!teacherId) {
      return res.status(400).json({ error: 'Teacher ID is required' });
    }

    // Find ticket
    const ticket = await Ticket.findById(ticketId);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    // Verify student owns the ticket
    if (ticket.student.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'You can only request teachers for your own tickets' });
    }

    // Verify teacher exists and is in the same category
    const teacher = await Teacher.findById(teacherId);
    if (!teacher) {
      return res.status(404).json({ error: 'Teacher not found' });
    }

    if (teacher.category.toString() !== ticket.category.toString()) {
      return res.status(400).json({ error: 'Teacher is not in the ticket\'s category' });
    }

    // Check if request already exists
    const existingRequest = ticket.requestedTeachers.find(
      req => req.teacher.toString() === teacherId
    );
    if (existingRequest) {
      return res.status(400).json({ error: 'Request already sent to this teacher' });
    }

    // Add teacher to requested teachers
    ticket.requestedTeachers.push({
      teacher: teacherId,
      status: 'pending',
    });

    await ticket.save();

    // Populate references
    await ticket.populate([
      { path: 'category', select: 'name' },
      { path: 'student', select: 'name email' },
      { path: 'requestedTeachers.teacher', select: 'name rating email' }
    ]);

    // Send email to teacher
    const teacherEmail = teacher.email;
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: teacherEmail,
      subject: 'New Ticket Request',
      html: `
        <h2>New Ticket Request!</h2>
        <p>Student <strong>${req.user.name}</strong> has sent you a ticket request.</p>
        <p><strong>Ticket Title:</strong> ${ticket.title}</p>
        <p><strong>Category:</strong> ${ticket.category.name}</p>
        <p><strong>Description:</strong> ${ticket.description}</p>
        <p>Please log in to your account to accept or reject this request.</p>
      `,
    });

    res.status(201).json({
      message: 'Request sent to teacher successfully',
      ticket,
    });
  } catch (error) {
    console.error('Error sending request to teacher:', error);
    res.status(500).json({ error: error.message || 'Failed to send request' });
  }
});

// ==================== SEND MULTIPLE REQUESTS ====================
// Student sends requests to multiple teachers at once
router.post('/:ticketId/request-teachers', authMiddleware, async (req, res) => {
  try {
    const { ticketId } = req.params;
    const { teacherIds } = req.body;

    if (!teacherIds || !Array.isArray(teacherIds) || teacherIds.length === 0) {
      return res.status(400).json({ error: 'At least one teacher ID is required' });
    }

    // Find ticket
    const ticket = await Ticket.findById(ticketId);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    // Verify student owns the ticket
    if (ticket.student.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'You can only request teachers for your own tickets' });
    }

    // Verify all teachers exist and are in the same category
    const teachers = await Teacher.find({ _id: { $in: teacherIds } });
    if (teachers.length !== teacherIds.length) {
      return res.status(404).json({ error: 'One or more teachers not found' });
    }

    // Check all teachers are in same category
    const invalidTeachers = teachers.filter(
      t => t.category.toString() !== ticket.category.toString()
    );
    if (invalidTeachers.length > 0) {
      return res.status(400).json({ error: 'One or more teachers are not in the ticket\'s category' });
    }

    // Add teachers to requested teachers (avoid duplicates)
    let addedCount = 0;
    for (const teacherId of teacherIds) {
      const existingRequest = ticket.requestedTeachers.find(
        req => req.teacher.toString() === teacherId
      );
      if (!existingRequest) {
        ticket.requestedTeachers.push({
          teacher: teacherId,
          status: 'pending',
        });
        addedCount++;
      }
    }

    await ticket.save();

    // Populate references
    await ticket.populate([
      { path: 'category', select: 'name' },
      { path: 'student', select: 'name email' },
      { path: 'requestedTeachers.teacher', select: 'name rating' }
    ]);

    res.json({
      message: `Successfully sent requests to ${addedCount} teacher(s)`,
      ticket,
    });
  } catch (error) {
    console.error('Error sending requests to teachers:', error);
    res.status(500).json({ error: error.message || 'Failed to send requests' });
  }
});

// ==================== GET STUDENT'S TICKETS ====================
// Student view all their tickets
router.get('/my-tickets', authMiddleware, async (req, res) => {
  try {
    const tickets = await Ticket.find({ student: req.user._id })
      .populate('category', 'name')
      .populate('student', 'name email')
      .populate('requestedTeachers.teacher', 'name rating')
      .sort({ createdAt: -1 });

    res.json({
      message: 'Your tickets fetched successfully',
      tickets,
    });
  } catch (error) {
    console.error('Error fetching student tickets:', error);
    res.status(500).json({ error: 'Failed to fetch tickets' });
  }
});

// ==================== GET TICKET BY ID ====================
// Student or admin view ticket details
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;

    const ticket = await Ticket.findById(id)
      .populate('category', 'name')
      .populate('student', 'name email')
      .populate('requestedTeachers.teacher', 'name rating description');

    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    // Verify student owns the ticket
    if (ticket.student._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'You do not have permission to view this ticket' });
    }

    res.json({
      message: 'Ticket fetched successfully',
      ticket,
    });
  } catch (error) {
    console.error('Error fetching ticket:', error);
    res.status(500).json({ error: 'Failed to fetch ticket' });
  }
});

// ==================== UPDATE TICKET ====================
// Student can update their ticket
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, budget, deadline, status } = req.body;

    const ticket = await Ticket.findById(id);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    // Verify student owns the ticket
    if (ticket.student.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'You can only update your own tickets' });
    }

    // Update fields if provided
    if (title) ticket.title = title.trim();
    if (description) ticket.description = description.trim();
    if (budget !== undefined) ticket.budget = budget;
    if (deadline) ticket.deadline = deadline;
    if (status) ticket.status = status;

    ticket.updatedAt = Date.now();
    await ticket.save();

    // Populate references
    await ticket.populate([
      { path: 'category', select: 'name' },
      { path: 'student', select: 'name email' },
      { path: 'requestedTeachers.teacher', select: 'name rating' }
    ]);

    res.json({
      message: 'Ticket updated successfully',
      ticket,
    });
  } catch (error) {
    console.error('Error updating ticket:', error);
    res.status(500).json({ error: 'Failed to update ticket' });
  }
});

// ==================== DELETE TICKET ====================
// Student can delete their ticket
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;

    const ticket = await Ticket.findById(id);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    // Verify student owns the ticket
    if (ticket.student.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'You can only delete your own tickets' });
    }

    await Ticket.findByIdAndDelete(id);

    res.json({
      message: 'Ticket deleted successfully',
    });
  } catch (error) {
    console.error('Error deleting ticket:', error);
    res.status(500).json({ error: 'Failed to delete ticket' });
  }
});

module.exports = router;
