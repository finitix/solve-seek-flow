const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const http = require('http');
const socketIO = require('socket.io');
require('dotenv').config();

//Middlewares
const authMiddleware = require('./middleware/auth');
const adminAuthMiddleware = require('./middleware/adminAuth');
const teacherAuthMiddleware = require('./middleware/teacherAuth');

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI)
.then(() => console.log('MongoDB connected successfully'))
.catch(err => console.error('MongoDB connection error:', err));

// WebSocket handler
const chatSocketHandler = require('./socket/chatSocket');
chatSocketHandler(io);

// Routes
const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const categoryRoutes = require('./routes/category');
const teacherRoutes = require('./routes/teacher');
const ticketRoutes = require('./routes/ticket');
const chatRoutes = require('./routes/chat');

app.use('/api/student/auth', authRoutes); //5
app.use('/api/admin', adminRoutes);  //7
app.use('/api/categories', categoryRoutes);  //5
app.use('/api/teachers', teacherRoutes);  //13
app.use('/api/tickets', ticketRoutes);  //8
app.use('/api/chat', chatRoutes); // New chat route

app.get('/', (req, res) => {
  res.json({ message: 'Welcome to the API' });
});

// ==================== PROTECTED ROUTE EXAMPLE ====================
// This route requires valid JWT token
app.get('/api/student/profile', authMiddleware, (req, res) => {
  res.json({
    message: 'Profile fetched successfully',
    user: req.user,
  });
});

// ==================== ADMIN PROTECTED ROUTE EXAMPLE ====================
// This route requires valid admin JWT token
app.get('/api/admin/dashboard', adminAuthMiddleware, (req, res) => {
  res.json({
    message: 'Admin dashboard accessed',
    admin: req.admin,
  });
});

// ==================== TEACHER PROTECTED ROUTE EXAMPLE ====================
// This route requires valid teacher JWT token
app.get('/api/teacher/dashboard', teacherAuthMiddleware, (req, res) => {
  res.json({
    message: 'Teacher dashboard accessed',
    teacher: req.teacher,
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal Server Error' });
});

// Start server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  console.log(`WebSocket server ready for connections`);
});
