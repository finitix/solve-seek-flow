const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const adminAuthMiddleware = require('../middleware/adminAuth');
const teacherAuthMiddleware = require('../middleware/teacherAuth');
const Teacher = require('../models/Teacher');
const Category = require('../models/Category');
const Ticket = require('../models/Ticket');

const router = express.Router();

// Configure Nodemailer
const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false,
  requireTLS: true,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
  tls: {
    rejectUnauthorized: false
  }
});

// Generate 6-digit OTP
const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// Generate JWT token for teacher
const generateTeacherToken = (teacher) => {
  return jwt.sign(
    { 
      id: teacher._id, 
      email: teacher.email,
      name: teacher.name,
      role: 'teacher'
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
};

// ==================== TEACHER LOGIN ====================
// Teacher login with email and password
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate email and password are provided
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    // Find teacher by email
    const teacher = await Teacher.findOne({ email: email.toLowerCase() })
      .populate('category', 'name');

    if (!teacher) {
      return res.status(404).json({ error: 'Teacher not found' });
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, teacher.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    // Generate JWT token
    const token = generateTeacherToken(teacher);

    res.json({
      message: 'Teacher login successful',
      token,
      teacher: {
        id: teacher._id,
        name: teacher.name,
        email: teacher.email,
        category: teacher.category,
        rating: teacher.rating,
      },
    });
  } catch (error) {
    console.error('Error during teacher login:', error);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// ==================== CREATE TEACHER (Admin Only) ====================
// Admin can create a new teacher with email and password
router.post('/', adminAuthMiddleware, async (req, res) => {
  try {
    const { name, email, password, category, rating, workExperience, description, projects } = req.body;

    // Validate required fields
    if (!name || !email || !password || !category) {
      return res.status(400).json({ error: 'Name, email, password, and category are required' });
    }

    // Check if teacher email already exists
    const existingTeacher = await Teacher.findOne({ email: email.toLowerCase() });
    if (existingTeacher) {
      return res.status(400).json({ error: 'Teacher with this email already exists' });
    }

    // Verify category exists
    const categoryExists = await Category.findById(category);
    if (!categoryExists) {
      return res.status(404).json({ error: 'Category not found' });
    }

    // Validate rating if provided
    if (rating && (rating < 0 || rating > 5)) {
      return res.status(400).json({ error: 'Rating must be between 0 and 5' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Validate projects if provided
    let projectsArray = [];
    if (projects && Array.isArray(projects)) {
      projectsArray = projects.map(project => {
        if (!project.title) {
          throw new Error('Project title is required');
        }
        if (!project.description && !project.image && !project.video && !project.link) {
          throw new Error('Project must have at least description, image, video, or link');
        }
        return {
          title: project.title.trim(),
          description: project.description?.trim() || '',
          image: project.image?.trim() || '',
          video: project.video?.trim() || '',
          link: project.link?.trim() || '',
        };
      });
    }

    // Create new teacher
    const teacher = new Teacher({
      name: name.trim(),
      email: email.toLowerCase(),
      password: hashedPassword,
      category,
      rating: rating || 0,
      workExperience: workExperience?.trim() || '',
      description: description?.trim() || '',
      projects: projectsArray,
      createdBy: req.admin._id,
    });

    await teacher.save();

    // Populate references before sending response
    await teacher.populate('category', 'name description');

    res.status(201).json({
      message: 'Teacher created successfully',
      teacher: {
        id: teacher._id,
        name: teacher.name,
        email: teacher.email,
        category: teacher.category,
        rating: teacher.rating,
      },
    });
  } catch (error) {
    console.error('Error creating teacher:', error);
    res.status(500).json({ error: error.message || 'Failed to create teacher' });
  }
});

// ==================== GET ALL TEACHERS ====================
// Anyone can view all teachers
router.get('/', async (req, res) => {
  try {
    const teachers = await Teacher.find()
      .populate('category', 'name');
    
    res.json({
      message: 'Teachers fetched successfully',
      teachers,
    });
  } catch (error) {
    console.error('Error fetching teachers:', error);
    res.status(500).json({ error: 'Failed to fetch teachers' });
  }
});

// ==================== GET TEACHER PROFILE (Teacher Only) ====================
// Teacher can view their own profile
// MUST come before /:id route to avoid conflict
router.get('/profile', teacherAuthMiddleware, async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.teacher._id)
      .populate('category', 'name')
      .select('-password -otp -resetToken -resetTokenExpiry -otpAttempts -otpExpiry -createdBy');

    res.json({
      message: 'Teacher profile fetched successfully',
      teacher,
    });
  } catch (error) {
    console.error('Error fetching teacher profile:', error);
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// ==================== GET TICKET REQUESTS FOR TEACHER ====================
// Teacher can view all ticket requests sent to them
// MUST come before /:id route
router.get('/requests/pending', teacherAuthMiddleware, async (req, res) => {
  try {
    // Find all tickets where this teacher has pending requests
    const tickets = await Ticket.find({
      'requestedTeachers.teacher': req.teacher._id,
      'requestedTeachers.status': 'pending'
    })
      .populate('category', 'name')
      .populate('student', 'name email')
      .populate('requestedTeachers.teacher', 'name rating');

    res.json({
      message: 'Pending ticket requests fetched successfully',
      totalRequests: tickets.length,
      tickets,
    });
  } catch (error) {
    console.error('Error fetching ticket requests:', error);
    res.status(500).json({ error: 'Failed to fetch requests' });
  }
});

// ==================== GET ALL TICKET REQUESTS FOR TEACHER ====================
// Teacher can view all ticket requests (pending, accepted, rejected)
// MUST come before /:id route
router.get('/requests/all', teacherAuthMiddleware, async (req, res) => {
  try {
    // Find all tickets where this teacher has requests
    const tickets = await Ticket.find({
      'requestedTeachers.teacher': req.teacher._id
    })
      .populate('category', 'name')
      .populate('student', 'name email')
      .populate('requestedTeachers.teacher', 'name rating')
      .sort({ createdAt: -1 });

    res.json({
      message: 'All ticket requests fetched successfully',
      totalRequests: tickets.length,
      tickets,
    });
  } catch (error) {
    console.error('Error fetching all requests:', error);
    res.status(500).json({ error: 'Failed to fetch requests' });
  }
});

// ==================== ACCEPT TICKET REQUEST (Teacher Only) ====================
// Teacher accepts a ticket request
// MUST come before /:id route
router.post('/requests/:ticketId/accept', teacherAuthMiddleware, async (req, res) => {
  try {
    const { ticketId } = req.params;

    // Find ticket
    const ticket = await Ticket.findById(ticketId);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    // Find the request for this teacher
    const requestIndex = ticket.requestedTeachers.findIndex(
      req => req.teacher.toString() === req.teacher._id.toString()
    );

    if (requestIndex === -1) {
      return res.status(404).json({ error: 'Request not found' });
    }

    // Check if request is still pending
    if (ticket.requestedTeachers[requestIndex].status !== 'pending') {
      return res.status(400).json({ 
        error: `Request already ${ticket.requestedTeachers[requestIndex].status}` 
      });
    }

    // Update request status to accepted
    ticket.requestedTeachers[requestIndex].status = 'accepted';
    ticket.requestedTeachers[requestIndex].respondedAt = new Date();
    ticket.status = 'in-progress';
    await ticket.save();

    // Populate references
    await ticket.populate([
      { path: 'category', select: 'name' },
      { path: 'student', select: 'name email' },
      { path: 'requestedTeachers.teacher', select: 'name rating' }
    ]);

    // Send email to student
    const studentEmail = ticket.student.email;
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: studentEmail,
      subject: 'Ticket Accepted - Teacher Response',
      html: `
        <h2>Ticket Accepted!</h2>
        <p>Great news! Teacher <strong>${req.teacher.name}</strong> has accepted your ticket request.</p>
        <p><strong>Ticket:</strong> ${ticket.title}</p>
        <p>The teacher will be in touch with you shortly.</p>
      `,
    });

    res.json({
      message: 'Ticket request accepted successfully',
      ticket,
    });
  } catch (error) {
    console.error('Error accepting request:', error);
    res.status(500).json({ error: error.message || 'Failed to accept request' });
  }
});

// ==================== REJECT TICKET REQUEST (Teacher Only) ====================
// Teacher rejects a ticket request
// MUST come before /:id route
router.post('/requests/:ticketId/reject', teacherAuthMiddleware, async (req, res) => {
  try {
    const { ticketId } = req.params;
    const { reason } = req.body;

    // Find ticket
    const ticket = await Ticket.findById(ticketId);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    // Find the request for this teacher
    const requestIndex = ticket.requestedTeachers.findIndex(
      req => req.teacher.toString() === req.teacher._id.toString()
    );

    if (requestIndex === -1) {
      return res.status(404).json({ error: 'Request not found' });
    }

    // Check if request is still pending
    if (ticket.requestedTeachers[requestIndex].status !== 'pending') {
      return res.status(400).json({ 
        error: `Request already ${ticket.requestedTeachers[requestIndex].status}` 
      });
    }

    // Update request status to rejected
    ticket.requestedTeachers[requestIndex].status = 'rejected';
    ticket.requestedTeachers[requestIndex].respondedAt = new Date();
    await ticket.save();

    // Populate references
    await ticket.populate([
      { path: 'category', select: 'name' },
      { path: 'student', select: 'name email' },
      { path: 'requestedTeachers.teacher', select: 'name rating' }
    ]);

    // Send email to student
    const studentEmail = ticket.student.email;
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: studentEmail,
      subject: 'Ticket Request Rejected',
      html: `
        <h2>Ticket Request Update</h2>
        <p>Teacher <strong>${req.teacher.name}</strong> has declined your ticket request.</p>
        <p><strong>Ticket:</strong> ${ticket.title}</p>
        ${reason ? `<p><strong>Reason:</strong> ${reason}</p>` : ''}
        <p>You can send requests to other teachers in this category.</p>
      `,
    });

    res.json({
      message: 'Ticket request rejected successfully',
      ticket,
    });
  } catch (error) {
    console.error('Error rejecting request:', error);
    res.status(500).json({ error: error.message || 'Failed to reject request' });
  }
});

// ==================== GET TEACHER BY ID ====================
// Anyone can view a specific teacher
// This MUST come AFTER all other /api/teachers/* routes
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const teacher = await Teacher.findById(id)
      .populate('category', 'name description')

    if (!teacher) {
      return res.status(404).json({ error: 'Teacher not found' });
    }

    res.json({
      message: 'Teacher fetched successfully',
      teacher,
    });
  } catch (error) {
    console.error('Error fetching teacher:', error);
    res.status(500).json({ error: 'Failed to fetch teacher' });
  }
});

// ==================== GET TEACHERS BY CATEGORY ====================
// Anyone can view teachers by category
router.get('/category/:categoryId', async (req, res) => {
  try {
    const { categoryId } = req.params;

    // Verify category exists
    const category = await Category.findById(categoryId);
    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }

    const teachers = await Teacher.find({ category: categoryId })
      .populate('category', 'name')
      .populate('createdBy', 'name email');

    res.json({
      message: `Teachers in ${category.name} fetched successfully`,
      teachers,
    });
  } catch (error) {
    console.error('Error fetching teachers by category:', error);
    res.status(500).json({ error: 'Failed to fetch teachers' });
  }
});

// ==================== TEACHER FORGOT PASSWORD ====================
// Teacher requests OTP for password reset
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    // Find teacher by email
    const teacher = await Teacher.findOne({ email: email.toLowerCase() });
    if (!teacher) {
      return res.status(404).json({ error: 'Teacher not found' });
    }

    // Generate OTP (expires in 10 minutes)
    const otp = generateOTP();
    const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

    // Hash OTP before storing
    const hashedOtp = await bcrypt.hash(otp, 10);

    teacher.otp = hashedOtp;
    teacher.otpExpiry = otpExpiry;
    teacher.otpAttempts = 0;
    await teacher.save();

    // Send OTP to teacher email
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: teacher.email,
      subject: 'Teacher Password Reset - OTP',
      html: `
        <h2>Password Reset Request</h2>
        <p>Your OTP for password reset is:</p>
        <h1 style="color: #007bff;">${otp}</h1>
        <p style="color: #666;">This OTP will expire in 10 minutes.</p>
        <p>If you didn't request this, please ignore this email.</p>
      `,
    });

    res.json({ message: 'OTP sent to your email for password reset' });
  } catch (error) {
    console.error('Error during teacher forgot password:', error);
    res.status(500).json({ error: 'Failed to send OTP. Please try again.' });
  }
});

// ==================== VERIFY RESET OTP (Teacher) ====================
// Teacher verifies OTP for password reset
router.post('/verify-reset-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({ error: 'Email and OTP are required' });
    }

    // Find teacher by email
    const teacher = await Teacher.findOne({ email: email.toLowerCase() });
    if (!teacher) {
      return res.status(404).json({ error: 'Teacher not found' });
    }

    // Check if teacher is blocked due to too many attempts
    if (teacher.otpAttempts >= 5) {
      return res.status(429).json({ 
        error: 'Too many failed attempts. Please request a new OTP.' 
      });
    }

    // Check if OTP has expired
    if (new Date() > teacher.otpExpiry) {
      return res.status(400).json({ error: 'OTP has expired. Please request a new one.' });
    }

    // Verify OTP
    const isOtpValid = await bcrypt.compare(otp, teacher.otp);
    if (!isOtpValid) {
      teacher.otpAttempts += 1;
      await teacher.save();
      
      const remainingAttempts = 5 - teacher.otpAttempts;
      return res.status(400).json({ 
        error: `Invalid OTP. ${remainingAttempts} attempts remaining.` 
      });
    }

    // Generate reset token
    const resetToken = Math.random().toString(36).substring(2, 15) + 
                       Math.random().toString(36).substring(2, 15);
    const hashedResetToken = await bcrypt.hash(resetToken, 10);

    teacher.resetToken = hashedResetToken;
    teacher.resetTokenExpiry = new Date(Date.now() + 10 * 60 * 1000);
    teacher.otp = null;
    teacher.otpExpiry = null;
    teacher.otpAttempts = 0;
    await teacher.save();

    res.json({
      message: 'OTP verified. You can now reset your password.',
      resetToken: resetToken,
    });
  } catch (error) {
    console.error('Error verifying reset OTP:', error);
    res.status(500).json({ error: 'OTP verification failed' });
  }
});

// ==================== RESET PASSWORD (Teacher) ====================
// Teacher resets password using reset token
router.post('/reset-password', async (req, res) => {
  try {
    const { email, resetToken, newPassword, confirmNewPassword } = req.body;

    if (!email || !resetToken || !newPassword || !confirmNewPassword) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    if (newPassword !== confirmNewPassword) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }

    // Find teacher by email
    const teacher = await Teacher.findOne({ email: email.toLowerCase() });
    if (!teacher) {
      return res.status(404).json({ error: 'Teacher not found' });
    }

    if (!teacher.resetToken) {
      return res.status(400).json({ error: 'No reset request found. Please request OTP again.' });
    }

    if (new Date() > teacher.resetTokenExpiry) {
      return res.status(400).json({ error: 'Reset token has expired. Please request OTP again.' });
    }

    // Verify reset token
    const isTokenValid = await bcrypt.compare(resetToken, teacher.resetToken);
    if (!isTokenValid) {
      return res.status(400).json({ error: 'Invalid reset token' });
    }

    // Hash new password and update
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    teacher.password = hashedPassword;
    teacher.resetToken = null;
    teacher.resetTokenExpiry = null;
    await teacher.save();

    res.json({ message: 'Password reset successful. You can now login with your new password.' });
  } catch (error) {
    console.error('Error resetting password:', error);
    res.status(500).json({ error: 'Password reset failed' });
  }
});

// ==================== ADD PROJECT TO TEACHER (Admin Only) ====================
// Admin can add a new project to an existing teacher
router.post('/:id/projects', adminAuthMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, image, video, link } = req.body;

    // Find teacher by ID
    const teacher = await Teacher.findById(id);
    if (!teacher) {
      return res.status(404).json({ error: 'Teacher not found' });
    }

    // Validate project title
    if (!title) {
      return res.status(400).json({ error: 'Project title is required' });
    }

    // Validate at least one media field is provided
    if (!description && !image && !video && !link) {
      return res.status(400).json({ 
        error: 'Project must have at least one of: description, image, video, or link' 
      });
    }

    // Add new project
    const newProject = {
      title: title.trim(),
      description: description?.trim() || '',
      image: image?.trim() || '',
      video: video?.trim() || '',
      link: link?.trim() || '',
    };

    teacher.projects.push(newProject);
    await teacher.save();

    // Populate references before sending response
    await teacher.populate('category', 'name description');

    res.status(201).json({
      message: 'Project added successfully',
      teacher,
    });
  } catch (error) {
    console.error('Error adding project:', error);
    res.status(500).json({ error: error.message || 'Failed to add project' });
  }
});

// ==================== UPDATE PROJECT (Admin Only) ====================
// Admin can update a specific project of a teacher
router.put('/:id/projects/:projectId', adminAuthMiddleware, async (req, res) => {
  try {
    const { id, projectId } = req.params;
    const { title, description, image, video, link } = req.body;

    // Find teacher by ID
    const teacher = await Teacher.findById(id);
    if (!teacher) {
      return res.status(404).json({ error: 'Teacher not found' });
    }

    // Find project by ID
    const project = teacher.projects.id(projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Update project fields if provided
    if (title) {
      project.title = title.trim();
    }
    if (description !== undefined) {
      project.description = description.trim();
    }
    if (image !== undefined) {
      project.image = image.trim();
    }
    if (video !== undefined) {
      project.video = video.trim();
    }
    if (link !== undefined) {
      project.link = link.trim();
    }

    // Validate at least one media field exists
    if (!project.description && !project.image && !project.video && !project.link) {
      return res.status(400).json({ 
        error: 'Project must have at least one of: description, image, video, or link' 
      });
    }

    await teacher.save();

    // Populate references before sending response
    await teacher.populate('category', 'name description');

    res.json({
      message: 'Project updated successfully',
      teacher,
    });
  } catch (error) {
    console.error('Error updating project:', error);
    res.status(500).json({ error: error.message || 'Failed to update project' });
  }
});

// ==================== DELETE PROJECT (Admin Only) ====================
// Admin can delete a specific project from a teacher
router.delete('/:id/projects/:projectId', adminAuthMiddleware, async (req, res) => {
  try {
    const { id, projectId } = req.params;

    // Find teacher by ID
    const teacher = await Teacher.findById(id);
    if (!teacher) {
      return res.status(404).json({ error: 'Teacher not found' });
    }

    // Find and remove project
    const project = teacher.projects.id(projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    project.deleteOne();
    await teacher.save();

    // Populate references before sending response
    await teacher.populate('category', 'name description');

    res.json({
      message: 'Project deleted successfully',
      teacher,
    });
  } catch (error) {
    console.error('Error deleting project:', error);
    res.status(500).json({ error: error.message || 'Failed to delete project' });
  }
});

// ==================== UPDATE TEACHER (Admin Only) ====================
// Admin can update teacher details (excluding projects)
router.put('/:id', adminAuthMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, category, rating, workExperience, description } = req.body;

    // Find teacher by ID
    const teacher = await Teacher.findById(id);
    if (!teacher) {
      return res.status(404).json({ error: 'Teacher not found' });
    }

    // Update name if provided
    if (name) {
      teacher.name = name.trim();
    }

    // Update category if provided and verify it exists
    if (category) {
      const categoryExists = await Category.findById(category);
      if (!categoryExists) {
        return res.status(404).json({ error: 'Category not found' });
      }
      teacher.category = category;
    }

    // Update rating if provided
    if (rating !== undefined) {
      if (rating < 0 || rating > 5) {
        return res.status(400).json({ error: 'Rating must be between 0 and 5' });
      }
      teacher.rating = rating;
    }

    // Update other fields if provided
    if (workExperience !== undefined) {
      teacher.workExperience = workExperience.trim();
    }
    if (description !== undefined) {
      teacher.description = description.trim();
    }

    await teacher.save();

    // Populate references before sending response
    await teacher.populate('category', 'name description');

    res.json({
      message: 'Teacher updated successfully',
      teacher,
    });
  } catch (error) {
    console.error('Error updating teacher:', error);
    res.status(500).json({ error: 'Failed to update teacher' });
  }
});

// ==================== DELETE TEACHER (Admin Only) ====================
// Admin can delete a teacher
router.delete('/:id', adminAuthMiddleware, async (req, res) => {
  try {
    const { id } = req.params;

    // Find and delete teacher
    const teacher = await Teacher.findByIdAndDelete(id);
    if (!teacher) {
      return res.status(404).json({ error: 'Teacher not found' });
    }

    res.json({
      message: 'Teacher deleted successfully',
      teacher,
    });
  } catch (error) {
    console.error('Error deleting teacher:', error);
    res.status(500).json({ error: 'Failed to delete teacher' });
  }
});

// ==================== GET TICKET REQUESTS FOR TEACHER ====================
// Teacher can view all ticket requests sent to them
router.get('/requests/pending', teacherAuthMiddleware, async (req, res) => {
  try {
    // Find all tickets where this teacher has pending requests
    const tickets = await Ticket.find({
      'requestedTeachers.teacher': req.teacher._id,
      'requestedTeachers.status': 'pending'
    })
      .populate('category', 'name')
      .populate('student', 'name email')

    res.json({
      message: 'Pending ticket requests fetched successfully',
      totalRequests: tickets.length,
      tickets,
    });
  } catch (error) {
    console.error('Error fetching ticket requests:', error);
    res.status(500).json({ error: 'Failed to fetch requests' });
  }
});

// ==================== GET ALL TICKET REQUESTS FOR TEACHER ====================
// Teacher can view all ticket requests (pending, accepted, rejected)
router.get('/requests/all', teacherAuthMiddleware, async (req, res) => {
  try {
    // Find all tickets where this teacher has requests
    const tickets = await Ticket.find({
      'requestedTeachers.teacher': req.teacher._id
    })
      .populate('category', 'name')
      .populate('student', 'name email')
      .sort({ createdAt: -1 });

    res.json({
      message: 'All ticket requests fetched successfully',
      totalRequests: tickets.length,
      tickets,
    });
  } catch (error) {
    console.error('Error fetching all requests:', error);
    res.status(500).json({ error: 'Failed to fetch requests' });
  }
});

// ==================== ACCEPT TICKET REQUEST (Teacher Only) ====================
// Teacher accepts a ticket request
router.post('/requests/:ticketId/accept', teacherAuthMiddleware, async (req, res) => {
  try {
    const { ticketId } = req.params;

    // Find ticket
    const ticket = await Ticket.findById(ticketId);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    // Find the request for this teacher
    const requestIndex = ticket.requestedTeachers.findIndex(
      req => req.teacher.toString() === req.teacher._id.toString()
    );

    if (requestIndex === -1) {
      return res.status(404).json({ error: 'Request not found' });
    }

    // Check if request is still pending
    if (ticket.requestedTeachers[requestIndex].status !== 'pending') {
      return res.status(400).json({ 
        error: `Request already ${ticket.requestedTeachers[requestIndex].status}` 
      });
    }

    // Update request status to accepted
    ticket.requestedTeachers[requestIndex].status = 'accepted';
    ticket.requestedTeachers[requestIndex].respondedAt = new Date();
    ticket.status = 'in-progress';
    await ticket.save();

    // Populate references
    await ticket.populate([
      { path: 'category', select: 'name' },
      { path: 'student', select: 'name email' },
      { path: 'requestedTeachers.teacher', select: 'name rating' }
    ]);

    // Send email to student
    const studentEmail = ticket.student.email;
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: studentEmail,
      subject: 'Ticket Accepted - Teacher Response',
      html: `
        <h2>Ticket Accepted!</h2>
        <p>Great news! Teacher <strong>${req.teacher.name}</strong> has accepted your ticket request.</p>
        <p><strong>Ticket:</strong> ${ticket.title}</p>
        <p>The teacher will be in touch with you shortly.</p>
      `,
    });

    res.json({
      message: 'Ticket request accepted successfully',
      ticket,
    });
  } catch (error) {
    console.error('Error accepting request:', error);
    res.status(500).json({ error: error.message || 'Failed to accept request' });
  }
});

// ==================== REJECT TICKET REQUEST (Teacher Only) ====================
// Teacher rejects a ticket request
router.post('/requests/:ticketId/reject', teacherAuthMiddleware, async (req, res) => {
  try {
    const { ticketId } = req.params;
    const { reason } = req.body;

    // Find ticket
    const ticket = await Ticket.findById(ticketId);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    // Find the request for this teacher
    const requestIndex = ticket.requestedTeachers.findIndex(
      req => req.teacher.toString() === req.teacher._id.toString()
    );

    if (requestIndex === -1) {
      return res.status(404).json({ error: 'Request not found' });
    }

    // Check if request is still pending
    if (ticket.requestedTeachers[requestIndex].status !== 'pending') {
      return res.status(400).json({ 
        error: `Request already ${ticket.requestedTeachers[requestIndex].status}` 
      });
    }

    // Update request status to rejected
    ticket.requestedTeachers[requestIndex].status = 'rejected';
    ticket.requestedTeachers[requestIndex].respondedAt = new Date();
    await ticket.save();

    // Populate references
    await ticket.populate([
      { path: 'category', select: 'name' },
      { path: 'student', select: 'name email' },
      { path: 'requestedTeachers.teacher', select: 'name rating' }
    ]);

    // Send email to student
    const studentEmail = ticket.student.email;
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: studentEmail,
      subject: 'Ticket Request Rejected',
      html: `
        <h2>Ticket Request Update</h2>
        <p>Teacher <strong>${req.teacher.name}</strong> has declined your ticket request.</p>
        <p><strong>Ticket:</strong> ${ticket.title}</p>
        ${reason ? `<p><strong>Reason:</strong> ${reason}</p>` : ''}
        <p>You can send requests to other teachers in this category.</p>
      `,
    });

    res.json({
      message: 'Ticket request rejected successfully',
      ticket,
    });
  } catch (error) {
    console.error('Error rejecting request:', error);
    res.status(500).json({ error: error.message || 'Failed to reject request' });
  }
});

module.exports = router;
