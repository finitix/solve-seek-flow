const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const User = require('../models/User');

const router = express.Router();

// Configure Nodemailer using XOAuth2 or TLS
const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false,
  requireTLS: true,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
  tls: {
    rejectUnauthorized: false
  }
});

// Generate 6-digit OTP
const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// Generate JWT token
const generateToken = (user) => {
  return jwt.sign(
    { 
      id: user._id, 
      email: user.email,
      name: user.name 
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
};

// ==================== SIGNUP ENDPOINT ====================
// User enters name, email, password and creates account
// OTP is sent to email but user cannot login until verified
router.post('/signup', async (req, res) => {
  try {
    const { name, email, password, confirmPassword } = req.body;

    // Validate all fields are provided
    if (!name || !email || !password || !confirmPassword) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Check if passwords match
    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }

    // Check if user already exists AND is verified
    const existingUser = await User.findOne({ email });
    if (existingUser && existingUser.isEmailVerified) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    // If unverified user exists with same email, delete them to allow re-signup
    if (existingUser && !existingUser.isEmailVerified) {
      await User.deleteOne({ email });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Generate OTP (expires in 10 minutes)
    const otp = generateOTP();
    const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

    // Hash OTP before storing (SECURITY: prevents exposure if DB leaks)
    const hashedOtp = await bcrypt.hash(otp, 10);

    // Create new user in database
    const newUser = new User({
      name,
      email,
      password: hashedPassword,
      otp: hashedOtp,
      otpExpiry,
      isEmailVerified: false,
    });

    await newUser.save();

    // Send OTP to user's email (plain OTP sent to email, hashed stored in DB)
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Verify Your Email - OTP',
      html: `
        <h2>Welcome ${name}!</h2>
        <p>Your OTP for email verification is:</p>
        <h1 style="color: #007bff;">${otp}</h1>
        <p style="color: #666;">This OTP will expire in 10 minutes.</p>
        <p>Please do not share this OTP with anyone.</p>
      `,
    });

    res.status(201).json({
      message: 'Signup successful! OTP sent to your email. Please verify your email to login.',
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        isEmailVerified: newUser.isEmailVerified,
      },
    });
  } catch (error) {
    console.error('Error during signup:', error);
    res.status(500).json({ error: 'Signup failed. Please try again.' });
  }
});

// ==================== VERIFY OTP ENDPOINT ====================
// User enters OTP received in email
// After verification, user can login
router.post('/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;

    // Validate email and OTP are provided
    if (!email || !otp) {
      return res.status(400).json({ error: 'Email and OTP are required' });
    }

    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check if user is blocked due to too many attempts (SECURITY: prevent brute-force)
    if (user.otpAttempts >= 5) {
      return res.status(429).json({ 
        error: 'Too many failed attempts. Please request a new OTP.' 
      });
    }

    // Check if OTP has expired
    if (new Date() > user.otpExpiry) {
      return res.status(400).json({ error: 'OTP has expired. Please request a new one.' });
    }

    // Verify OTP using bcrypt.compare (SECURITY: compare hashed OTP)
    const isOtpValid = await bcrypt.compare(otp, user.otp);
    if (!isOtpValid) {
      // Increment failed attempts counter
      user.otpAttempts += 1;
      await user.save();
      
      const remainingAttempts = 5 - user.otpAttempts;
      return res.status(400).json({ 
        error: `Invalid OTP. ${remainingAttempts} attempts remaining.` 
      });
    }

    // Mark email as verified and clear OTP (reset attempts on success)
    user.isEmailVerified = true;
    user.otp = null;
    user.otpExpiry = null;
    user.otpAttempts = 0;
    await user.save();

    // Generate JWT token for automatic login after verification
    const token = generateToken(user);

    res.json({
      message: 'Email verified successfully! You are now logged in.',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        isEmailVerified: user.isEmailVerified,
      },
    });
  } catch (error) {
    console.error('Error verifying OTP:', error);
    res.status(500).json({ error: 'OTP verification failed' });
  }
});

// ==================== RESEND OTP ENDPOINT ====================
// User can request a new OTP if the previous one expired
router.post('/resend-otp', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check if user is already verified
    if (user.isEmailVerified) {
      return res.status(400).json({ error: 'User is already verified' });
    }

    // Generate new OTP (expires in 10 minutes)
    const otp = generateOTP();
    const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

    // Hash OTP before storing (SECURITY: prevents exposure if DB leaks)
    const hashedOtp = await bcrypt.hash(otp, 10);

    user.otp = hashedOtp;
    user.otpExpiry = otpExpiry;
    user.otpAttempts = 0; // Reset attempts on new OTP request
    await user.save();

    // Send new OTP to email (plain OTP sent to email, hashed stored in DB)
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Verify Your Email - New OTP',
      html: `
        <h2>New OTP Request</h2>
        <p>Your new OTP for email verification is:</p>
        <h1 style="color: #007bff;">${otp}</h1>
        <p style="color: #666;">This OTP will expire in 10 minutes.</p>
      `,
    });

    res.json({ message: 'New OTP sent to your email' });
  } catch (error) {
    console.error('Error resending OTP:', error);
    res.status(500).json({ error: 'Failed to resend OTP' });
  }
});

// ==================== LOGIN ENDPOINT ====================
// User enters email and password to login
// Only verified users can login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate email and password are provided
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check if email is verified
    if (!user.isEmailVerified) {
      return res.status(403).json({ 
        error: 'Email not verified. Please verify your email first. Re-Register' 
      });
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    // Generate JWT token
    const token = generateToken(user);

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        isEmailVerified: user.isEmailVerified,
      },
    });
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// ==================== FORGOT PASSWORD ENDPOINT ====================
// User enters email to receive OTP for password reset
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check if user is verified
    if (!user.isEmailVerified) {
      return res.status(403).json({ 
        error: 'Email not verified. Please verify your email first. Re-Register' 
      });
    }

    // Generate OTP (expires in 10 minutes)
    const otp = generateOTP();
    const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

    // Hash OTP before storing (SECURITY: prevents exposure if DB leaks)
    const hashedOtp = await bcrypt.hash(otp, 10);

    user.otp = hashedOtp;
    user.otpExpiry = otpExpiry;
    user.otpAttempts = 0;
    await user.save();

    // Send OTP to email
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Password Reset - OTP',
      html: `
        <h2>Password Reset Request</h2>
        <p>Your OTP for password reset is:</p>
        <h1 style="color: #007bff;">${otp}</h1>
        <p style="color: #666;">This OTP will expire in 10 minutes.</p>
        <p>If you didn't request this, please ignore this email.</p>
      `,
    });

    res.json({ message: 'OTP sent to your email for password reset' });
  } catch (error) {
    console.error('Error during forgot password:', error);
    res.status(500).json({ error: 'Failed to send OTP. Please try again.' });
  }
});

// ==================== VERIFY RESET OTP ENDPOINT ====================
// User enters OTP received in email for password reset
// Returns a reset token on successful verification
router.post('/verify-reset-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;

    // Validate email and OTP are provided
    if (!email || !otp) {
      return res.status(400).json({ error: 'Email and OTP are required' });
    }

    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check if user is blocked due to too many attempts (SECURITY: prevent brute-force)
    if (user.otpAttempts >= 5) {
      return res.status(429).json({ 
        error: 'Too many failed attempts. Please request a new OTP.' 
      });
    }

    // Check if OTP has expired
    if (new Date() > user.otpExpiry) {
      return res.status(400).json({ error: 'OTP has expired. Please request a new one.' });
    }

    // Verify OTP using bcrypt.compare (SECURITY: compare hashed OTP)
    const isOtpValid = await bcrypt.compare(otp, user.otp);
    if (!isOtpValid) {
      // Increment failed attempts counter
      user.otpAttempts += 1;
      await user.save();
      
      const remainingAttempts = 5 - user.otpAttempts;
      return res.status(400).json({ 
        error: `Invalid OTP. ${remainingAttempts} attempts remaining.` 
      });
    }

    // Generate reset token (valid for 10 minutes)
    const resetToken = Math.random().toString(36).substring(2, 15) + 
                       Math.random().toString(36).substring(2, 15);
    const hashedResetToken = await bcrypt.hash(resetToken, 10);

    // Store reset token and clear OTP
    user.resetToken = hashedResetToken;
    user.resetTokenExpiry = new Date(Date.now() + 10 * 60 * 1000);
    user.otp = null;
    user.otpExpiry = null;
    user.otpAttempts = 0;
    await user.save();

    res.json({
      message: 'OTP verified. You can now reset your password.',
      resetToken: resetToken,
    });
  } catch (error) {
    console.error('Error verifying reset OTP:', error);
    res.status(500).json({ error: 'OTP verification failed' });
  }
});

// ==================== RESET PASSWORD ENDPOINT ====================
// User enters new password after OTP verification
router.post('/reset-password', async (req, res) => {
  try {
    const { email, resetToken, newPassword, confirmNewPassword } = req.body;

    // Validate all fields are provided
    if (!email || !resetToken || !newPassword || !confirmNewPassword) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Check if passwords match
    if (newPassword !== confirmNewPassword) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }

    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check if reset token exists
    if (!user.resetToken) {
      return res.status(400).json({ error: 'No reset request found. Please request OTP again.' });
    }

    // Check if reset token has expired
    if (new Date() > user.resetTokenExpiry) {
      return res.status(400).json({ error: 'Reset token has expired. Please request OTP again.' });
    }

    // Verify reset token
    const isTokenValid = await bcrypt.compare(resetToken, user.resetToken);
    if (!isTokenValid) {
      return res.status(400).json({ error: 'Invalid reset token' });
    }

    // Hash new password and update
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    user.resetToken = null;
    user.resetTokenExpiry = null;
    await user.save();

    res.json({ message: 'Password reset successful. You can now login with your new password.' });
  } catch (error) {
    console.error('Error resetting password:', error);
    res.status(500).json({ error: 'Password reset failed' });
  }
});

module.exports = router;
