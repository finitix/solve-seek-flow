const jwt = require('jsonwebtoken');
const Teacher = require('../models/Teacher');

// Middleware to verify teacher JWT token
const teacherAuthMiddleware = async (req, res, next) => {
  try {
    // Get token from header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Access denied. No token provided.' });
    }

    // Extract token from "Bearer <token>"
    const token = authHeader.split(' ')[1];

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Find teacher and attach to request
    const teacher = await Teacher.findById(decoded.id).select('-password -otp -resetToken');
    if (!teacher) {
      return res.status(401).json({ error: 'Teacher not found.' });
    }

    // Attach teacher to request object
    req.teacher = teacher;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired. Please login again.' });
    }
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Invalid token.' });
    }
    console.error('Teacher auth middleware error:', error);
    res.status(500).json({ error: 'Authentication failed.' });
  }
};

module.exports = teacherAuthMiddleware;
