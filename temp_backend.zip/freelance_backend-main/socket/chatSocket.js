const jwt = require('jsonwebtoken');
const ChatMessage = require('../models/ChatMessage');
const Ticket = require('../models/Ticket');
const User = require('../models/User');
const Teacher = require('../models/Teacher');

// Store active connections: { ticketId: [{ userId, socketId, role, name }] }
const activeChats = {};

const chatSocketHandler = (io) => {
  io.on('connection', (socket) => {
    console.log(`User connected: ${socket.id}`);

    // ==================== JOIN CHAT ====================
    // User joins a ticket chat room
    socket.on('join-chat', async (data) => {
      try {
        const { token, ticketId, role } = data;

        if (!token || !ticketId || !role) {
          return socket.emit('error', { message: 'Missing required fields' });
        }

        // Verify token
        let user;
        try {
          const decoded = jwt.verify(token, process.env.JWT_SECRET);
          
          if (role === 'student') {
            user = await User.findById(decoded.id);
          } else if (role === 'teacher') {
            user = await Teacher.findById(decoded.id);
          }
          
          if (!user) {
            return socket.emit('error', { message: 'User not found' });
          }
        } catch (err) {
          return socket.emit('error', { message: 'Invalid token' });
        }

        // Verify ticket exists and user has access
        const ticket = await Ticket.findById(ticketId);
        if (!ticket) {
          return socket.emit('error', { message: 'Ticket not found' });
        }

        if (role === 'student' && ticket.student.toString() !== user._id.toString()) {
          return socket.emit('error', { message: 'Unauthorized access' });
        }

        if (role === 'teacher') {
          const acceptedRequest = ticket.requestedTeachers.find(
            req => req.teacher.toString() === user._id.toString() && req.status === 'accepted'
          );
          if (!acceptedRequest) {
            return socket.emit('error', { message: 'No accepted request for this ticket' });
          }
        }

        // Join room
        socket.join(`ticket-${ticketId}`);

        // Store connection
        if (!activeChats[ticketId]) {
          activeChats[ticketId] = [];
        }
        activeChats[ticketId].push({
          userId: user._id.toString(),
          socketId: socket.id,
          role,
          name: user.name,
        });

        // Notify others
        socket.to(`ticket-${ticketId}`).emit('user-joined', {
          role,
          name: user.name,
          message: `${user.name} joined the chat`,
        });

        socket.emit('join-success', {
          message: `Successfully joined chat for ticket ${ticketId}`,
          ticketId,
        });

        console.log(`${user.name} (${role}) joined ticket ${ticketId}`);
      } catch (error) {
        console.error('Error joining chat:', error);
        socket.emit('error', { message: 'Failed to join chat' });
      }
    });

    // ==================== SEND MESSAGE ====================
    // User sends a message
    socket.on('send-message', async (data) => {
      try {
        const { ticketId, message, token, role } = data;

        if (!ticketId || !message || !token || !role) {
          return socket.emit('error', { message: 'Missing required fields' });
        }

        // Verify token and get user
        let user;
        try {
          const decoded = jwt.verify(token, process.env.JWT_SECRET);
          
          if (role === 'student') {
            user = await User.findById(decoded.id);
          } else if (role === 'teacher') {
            user = await Teacher.findById(decoded.id);
          }
          
          if (!user) {
            return socket.emit('error', { message: 'User not found' });
          }
        } catch (err) {
          return socket.emit('error', { message: 'Invalid token' });
        }

        // Verify user is in the chat room
        const roomUsers = activeChats[ticketId] || [];
        const isUserInRoom = roomUsers.some(u => u.userId === user._id.toString());
        if (!isUserInRoom) {
          return socket.emit('error', { message: 'You are not in this chat room' });
        }

        // Save message to database
        const chatMessage = new ChatMessage({
          ticket: ticketId,
          [role === 'student' ? 'sender' : 'senderTeacher']: user._id,
          senderRole: role,
          senderName: user.name,
          message: message.trim(),
        });

        await chatMessage.save();

        // Emit message to all users in the room
        io.to(`ticket-${ticketId}`).emit('receive-message', {
          id: chatMessage._id,
          senderRole: role,
          senderName: user.name,
          message: chatMessage.message,
          createdAt: chatMessage.createdAt,
        });

        console.log(`Message from ${user.name} in ticket ${ticketId}: ${message}`);
      } catch (error) {
        console.error('Error sending message:', error);
        socket.emit('error', { message: 'Failed to send message' });
      }
    });

    // ==================== TYPING INDICATOR ====================
    // User is typing
    socket.on('typing', (data) => {
      const { ticketId, userName } = data;
      socket.to(`ticket-${ticketId}`).emit('user-typing', {
        userName,
        message: `${userName} is typing...`,
      });
    });

    // ==================== STOP TYPING ====================
    socket.on('stop-typing', (data) => {
      const { ticketId } = data;
      socket.to(`ticket-${ticketId}`).emit('user-stop-typing', {});
    });

    // ==================== DISCONNECT ====================
    socket.on('disconnect', () => {
      // Remove user from all active chats
      for (const [ticketId, users] of Object.entries(activeChats)) {
        const index = users.findIndex(u => u.socketId === socket.id);
        if (index !== -1) {
          const user = users[index];
          users.splice(index, 1);

          // Notify others
          io.to(`ticket-${ticketId}`).emit('user-left', {
            name: user.name,
            message: `${user.name} left the chat`,
          });

          // Clean up empty rooms
          if (users.length === 0) {
            delete activeChats[ticketId];
          }

          console.log(`${user.name} left ticket ${ticketId}`);
        }
      }

      console.log(`User disconnected: ${socket.id}`);
    });

    // ==================== ERROR HANDLER ====================
    socket.on('error', (error) => {
      console.error('Socket error:', error);
    });
  });
};

module.exports = chatSocketHandler;
