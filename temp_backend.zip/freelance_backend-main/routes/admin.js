const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const Admin = require('../models/Admin');

const router = express.Router();

// Configure Nodemailer
const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false,
  requireTLS: true,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
  tls: {
    rejectUnauthorized: false
  }
});

// Generate 6-digit OTP
const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// Generate JWT token for admin
const generateAdminToken = (admin) => {
  return jwt.sign(
    { 
      id: admin._id, 
      email: admin.email,
      name: admin.name,
      role: 'admin'
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
};

// ==================== ADMIN LOGIN ENDPOINT ====================
// Admin enters email and password to login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate email and password are provided
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    // Find admin by email
    const admin = await Admin.findOne({ email: email });
    if (!admin) {
      return res.status(404).json({ error: 'Admin not found' });
    }

    // Verify password (compare with hashed password)
    const isPasswordValid = await bcrypt.compare(password, admin.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    // Generate JWT token
    const token = generateAdminToken(admin);

    res.json({
      message: 'Admin login successful',
      token,
      admin: {
        id: admin._id,
        name: admin.name,
        email: admin.email,
        role: 'admin',
      },
    });
  } catch (error) {
    console.error('Error during admin login:', error);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// ==================== ONE-TIME ADMIN SETUP ENDPOINT ====================
// Create hardcoded admin account (should be called only once)
router.post('/setup', async (req, res) => {
  try {
    // Check if admin already exists
    const existingAdmin = await Admin.findOne({ email: process.env.ADMIN_EMAIL });
    if (existingAdmin) {
      return res.status(400).json({ error: 'Admin already exists. Setup already completed.' });
    }

    const { name, password } = req.body;

    if (!name || !password) {
      return res.status(400).json({ error: 'Name and password are required' });
    }

    // Hash password with bcrypt (salt rounds: 10)
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create admin with hardcoded email from .env
    const admin = new Admin({
      name,
      email: process.env.ADMIN_EMAIL,
      password: hashedPassword,
    });

    await admin.save();

    res.status(201).json({
      message: 'Admin account created successfully',
      admin: {
        id: admin._id,
        name: admin.name,
        email: admin.email,
      },
    });
  } catch (error) {
    console.error('Error creating admin:', error);
    res.status(500).json({ error: 'Failed to create admin account' });
  }
});

// ==================== ADMIN FORGOT PASSWORD ENDPOINT ====================
// Admin enters email to receive OTP for password reset
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    // Find admin by email
    const admin = await Admin.findOne({ email: email.toLowerCase() });
    if (!admin) {
      return res.status(404).json({ error: 'Admin not found' });
    }

    // Generate OTP (expires in 10 minutes)
    const otp = generateOTP();
    const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);

    // Hash OTP before storing (SECURITY: prevents exposure if DB leaks)
    const hashedOtp = await bcrypt.hash(otp, 10);

    admin.otp = hashedOtp;
    admin.otpExpiry = otpExpiry;
    admin.otpAttempts = 0;
    await admin.save();

    // Send OTP to admin email
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: admin.email,
      subject: 'Admin Password Reset - OTP',
      html: `
        <h2>Admin Password Reset Request</h2>
        <p>Your OTP for password reset is:</p>
        <h1 style="color: #007bff;">${otp}</h1>
        <p style="color: #666;">This OTP will expire in 10 minutes.</p>
        <p>If you didn't request this, please ignore this email.</p>
      `,
    });

    res.json({ message: 'OTP sent to your email for password reset' });
  } catch (error) {
    console.error('Error during admin forgot password:', error);
    res.status(500).json({ error: 'Failed to send OTP. Please try again.' });
  }
});

// ==================== ADMIN VERIFY RESET OTP ENDPOINT ====================
// Admin enters OTP received in email for password reset
router.post('/verify-reset-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;

    // Validate email and OTP are provided
    if (!email || !otp) {
      return res.status(400).json({ error: 'Email and OTP are required' });
    }

    // Find admin by email
    const admin = await Admin.findOne({ email: email.toLowerCase() });
    if (!admin) {
      return res.status(404).json({ error: 'Admin not found' });
    }

    // Check if admin is blocked due to too many attempts (SECURITY: prevent brute-force)
    if (admin.otpAttempts >= 5) {
      return res.status(429).json({ 
        error: 'Too many failed attempts. Please request a new OTP.' 
      });
    }

    // Check if OTP has expired
    if (new Date() > admin.otpExpiry) {
      return res.status(400).json({ error: 'OTP has expired. Please request a new one.' });
    }

    // Verify OTP using bcrypt.compare (SECURITY: compare hashed OTP)
    const isOtpValid = await bcrypt.compare(otp, admin.otp);
    if (!isOtpValid) {
      // Increment failed attempts counter
      admin.otpAttempts += 1;
      await admin.save();
      
      const remainingAttempts = 5 - admin.otpAttempts;
      return res.status(400).json({ 
        error: `Invalid OTP. ${remainingAttempts} attempts remaining.` 
      });
    }

    // Generate reset token (valid for 10 minutes)
    const resetToken = Math.random().toString(36).substring(2, 15) + 
                       Math.random().toString(36).substring(2, 15);
    const hashedResetToken = await bcrypt.hash(resetToken, 10);

    // Store reset token and clear OTP
    admin.resetToken = hashedResetToken;
    admin.resetTokenExpiry = new Date(Date.now() + 10 * 60 * 1000);
    admin.otp = null;
    admin.otpExpiry = null;
    admin.otpAttempts = 0;
    await admin.save();

    res.json({
      message: 'OTP verified. You can now reset your password.',
      resetToken: resetToken,
    });
  } catch (error) {
    console.error('Error verifying admin reset OTP:', error);
    res.status(500).json({ error: 'OTP verification failed' });
  }
});

// ==================== ADMIN RESET PASSWORD ENDPOINT ====================
// Admin enters new password after OTP verification
router.post('/reset-password', async (req, res) => {
  try {
    const { email, resetToken, newPassword, confirmNewPassword } = req.body;

    // Validate all fields are provided
    if (!email || !resetToken || !newPassword || !confirmNewPassword) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Check if passwords match
    if (newPassword !== confirmNewPassword) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }

    // Find admin by email
    const admin = await Admin.findOne({ email: email.toLowerCase() });
    if (!admin) {
      return res.status(404).json({ error: 'Admin not found' });
    }

    // Check if reset token exists
    if (!admin.resetToken) {
      return res.status(400).json({ error: 'No reset request found. Please request OTP again.' });
    }

    // Check if reset token has expired
    if (new Date() > admin.resetTokenExpiry) {
      return res.status(400).json({ error: 'Reset token has expired. Please request OTP again.' });
    }

    // Verify reset token
    const isTokenValid = await bcrypt.compare(resetToken, admin.resetToken);
    if (!isTokenValid) {
      return res.status(400).json({ error: 'Invalid reset token' });
    }

    // Hash new password and update
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    admin.password = hashedPassword;
    admin.resetToken = null;
    admin.resetTokenExpiry = null;
    await admin.save();

    res.json({ message: 'Password reset successful. You can now login with your new password.' });
  } catch (error) {
    console.error('Error resetting admin password:', error);
    res.status(500).json({ error: 'Password reset failed' });
  }
});

module.exports = router;
