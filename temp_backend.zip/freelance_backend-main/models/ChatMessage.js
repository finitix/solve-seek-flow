const mongoose = require('mongoose');

const chatMessageSchema = new mongoose.Schema({
  ticket: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Ticket',
    required: true,
  },
  sender: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: function() { return this.senderRole === 'student'; }
  },
  senderTeacher: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Teacher',
    required: function() { return this.senderRole === 'teacher'; }
  },
  senderRole: {
    type: String,
    enum: ['student', 'teacher'],
    required: true,
  },
  senderName: {
    type: String,
    required: true,
  },
  message: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('ChatMessage', chatMessageSchema);
