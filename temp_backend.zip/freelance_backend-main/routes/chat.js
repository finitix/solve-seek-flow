const express = require('express');
const authMiddleware = require('../middleware/auth');
const teacherAuthMiddleware = require('../middleware/teacherAuth');
const ChatMessage = require('../models/ChatMessage');
const Ticket = require('../models/Ticket');

const router = express.Router();

// ==================== GET CHAT MESSAGES (Student) ====================
// Student can view chat messages for a ticket
router.get('/ticket/:ticketId', authMiddleware, async (req, res) => {
  try {
    const { ticketId } = req.params;

    // Find ticket and verify student owns it
    const ticket = await Ticket.findById(ticketId);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    if (ticket.student.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'You do not have permission to view this chat' });
    }

    // Check if ticket has accepted teacher request
    const acceptedRequest = ticket.requestedTeachers.find(
      req => req.status === 'accepted'
    );
    if (!acceptedRequest) {
      return res.status(400).json({ error: 'No accepted teacher request for this ticket' });
    }

    // Fetch messages
    const messages = await ChatMessage.find({ ticket: ticketId })
      .sort({ createdAt: 1 });

    res.json({
      message: 'Chat messages fetched successfully',
      ticketId,
      messages,
    });
  } catch (error) {
    console.error('Error fetching chat messages:', error);
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

// ==================== GET CHAT MESSAGES (Teacher) ====================
// Teacher can view chat messages for a ticket
router.get('/teacher/ticket/:ticketId', teacherAuthMiddleware, async (req, res) => {
  try {
    const { ticketId } = req.params;

    // Find ticket and verify teacher has accepted request
    const ticket = await Ticket.findById(ticketId);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    const acceptedRequest = ticket.requestedTeachers.find(
      req => req.teacher.toString() === req.teacher._id.toString() && req.status === 'accepted'
    );
    if (!acceptedRequest) {
      return res.status(403).json({ error: 'You do not have permission to view this chat' });
    }

    // Fetch messages
    const messages = await ChatMessage.find({ ticket: ticketId })
      .sort({ createdAt: 1 });

    res.json({
      message: 'Chat messages fetched successfully',
      ticketId,
      messages,
    });
  } catch (error) {
    console.error('Error fetching chat messages:', error);
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

module.exports = router;
