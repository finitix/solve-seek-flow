const express = require('express');
const adminAuthMiddleware = require('../middleware/adminAuth');
const Category = require('../models/Category');

const router = express.Router();

// ==================== GET ALL CATEGORIES ====================
// Anyone can view categories (no auth required)
router.get('/', async (req, res) => {
  try {
    const categories = await Category.find().populate('createdBy', 'name email');
    
    res.json({
      message: 'Categories fetched successfully',
      categories,
    });
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
});

// ==================== GET CATEGORY BY ID ====================
// Anyone can view a specific category
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const category = await Category.findById(id).populate('createdBy', 'name email');
    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }

    res.json({
      message: 'Category fetched successfully',
      category,
    });
  } catch (error) {
    console.error('Error fetching category:', error);
    res.status(500).json({ error: 'Failed to fetch category' });
  }
});

// ==================== CREATE CATEGORY (Admin Only) ====================
// Admin can create a new category
router.post('/', adminAuthMiddleware, async (req, res) => {
  try {
    const { name, description } = req.body;

    // Validate required fields
    if (!name) {
      return res.status(400).json({ error: 'Category name is required' });
    }

    // Check if category already exists
    const existingCategory = await Category.findOne({ name: name.trim() });
    if (existingCategory) {
      return res.status(400).json({ error: 'Category already exists' });
    }

    // Create new category
    const category = new Category({
      name: name.trim(),
      description: description?.trim() || '',
      createdBy: req.admin._id,
    });

    await category.save();

    // Populate admin details before sending response
    await category.populate('createdBy', 'name email');

    res.status(201).json({
      message: 'Category created successfully',
      category,
    });
  } catch (error) {
    console.error('Error creating category:', error);
    res.status(500).json({ error: 'Failed to create category' });
  }
});

// ==================== UPDATE CATEGORY (Admin Only) ====================
// Admin can update a category
router.put('/:id', adminAuthMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description } = req.body;

    // Find category by ID
    const category = await Category.findById(id);
    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }

    // Check if new name already exists (if name is being changed)
    if (name && name.trim() !== category.name) {
      const existingCategory = await Category.findOne({ name: name.trim() });
      if (existingCategory) {
        return res.status(400).json({ error: 'Category name already exists' });
      }
      category.name = name.trim();
    }

    // Update description if provided
    if (description !== undefined) {
      category.description = description.trim();
    }

    await category.save();

    // Populate admin details before sending response
    await category.populate('createdBy', 'name email');

    res.json({
      message: 'Category updated successfully',
      category,
    });
  } catch (error) {
    console.error('Error updating category:', error);
    res.status(500).json({ error: 'Failed to update category' });
  }
});

// ==================== DELETE CATEGORY (Admin Only) ====================
// Admin can delete a category
router.delete('/:id', adminAuthMiddleware, async (req, res) => {
  try {
    const { id } = req.params;

    // Find and delete category
    const category = await Category.findByIdAndDelete(id);
    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }

    res.json({
      message: 'Category deleted successfully',
      category,
    });
  } catch (error) {
    console.error('Error deleting category:', error);
    res.status(500).json({ error: 'Failed to delete category' });
  }
});

module.exports = router;
